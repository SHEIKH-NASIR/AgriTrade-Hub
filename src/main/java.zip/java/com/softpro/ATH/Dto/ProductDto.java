package com.softpro.ATH.Dto;

import java.math.BigDecimal;

import org.springframework.web.multipart.MultipartFile;

import com.softpro.ATH.Model.Formers;

public class ProductDto {

    private Long id;

    private String productName;

    private int quantity;

    private BigDecimal pricePerUnit;

    private String category;

    private Formers farmer;

    private String status;

    private MultipartFile image;

    // =========================
    // MARKETPLACE / BULK FIELDS
    // =========================

    /**
     * Minimum quantity a normal marketplace buyer can order.
     */
    private int minimumOrderQuantity;

    /**
     * Minimum quantity required for a bulk order.
     */
    private int bulkMinimumQuantity;

    /**
     * Price per unit applicable to bulk orders.
     */
    private BigDecimal bulkPricePerUnit;

    private String sellingMode = "INDEPENDENT";

    private Long fpoId;


    // =========================
    // ID
    // =========================

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }


    // =========================
    // PRODUCT NAME
    // =========================

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }


    // =========================
    // QUANTITY
    // =========================

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }


    // =========================
    // NORMAL PRICE
    // =========================

    public BigDecimal getPricePerUnit() {
        return pricePerUnit;
    }

    public void setPricePerUnit(BigDecimal pricePerUnit) {
        this.pricePerUnit = pricePerUnit;
    }


    // =========================
    // CATEGORY
    // =========================

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }


    // =========================
    // FARMER
    // =========================

    public Formers getFarmer() {
        return farmer;
    }

    public void setFarmer(Formers farmer) {
        this.farmer = farmer;
    }


    // =========================
    // STATUS
    // =========================

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }


    // =========================
    // IMAGE
    // =========================

    public MultipartFile getImage() {
        return image;
    }

    public void setImage(MultipartFile image) {
        this.image = image;
    }


    // =========================
    // MINIMUM ORDER QUANTITY
    // =========================

    public int getMinimumOrderQuantity() {
        return minimumOrderQuantity;
    }

    public void setMinimumOrderQuantity(int minimumOrderQuantity) {
        this.minimumOrderQuantity = minimumOrderQuantity;
    }


    // =========================
    // BULK MINIMUM QUANTITY
    // =========================

    public int getBulkMinimumQuantity() {
        return bulkMinimumQuantity;
    }

    public void setBulkMinimumQuantity(int bulkMinimumQuantity) {
        this.bulkMinimumQuantity = bulkMinimumQuantity;
    }


    // =========================
    // BULK PRICE PER UNIT
    // =========================

    public BigDecimal getBulkPricePerUnit() {
        return bulkPricePerUnit;
    }

    public void setBulkPricePerUnit(BigDecimal bulkPricePerUnit) {
        this.bulkPricePerUnit = bulkPricePerUnit;
    }

    public String getSellingMode() {
        return sellingMode;
    }

    public void setSellingMode(String sellingMode) {
        this.sellingMode = sellingMode;
    }

    public Long getFpoId() {
        return fpoId;
    }

    public void setFpoId(Long fpoId) {
        this.fpoId = fpoId;
    }
}