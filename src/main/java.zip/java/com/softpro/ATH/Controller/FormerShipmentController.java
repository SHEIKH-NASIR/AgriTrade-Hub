
package com.softpro.ATH.Controller;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.softpro.ATH.Dto.RouteOptimizationResponse;
import com.softpro.ATH.Model.FPOShipment;
import com.softpro.ATH.Model.Formers;
import com.softpro.ATH.Model.Order;
import com.softpro.ATH.Repository.FPOShipmentRepo;
import com.softpro.ATH.Repository.FormersRepo;
import com.softpro.ATH.Repository.OrderRepo;
import com.softpro.ATH.Service.DemoAccessService;
import com.softpro.ATH.Service.GeocodingService;
import com.softpro.ATH.Service.RouteOptimizationService;
import com.softpro.ATH.Service.ShipmentNotificationService;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/Former/Shipments")
public class FormerShipmentController {

    @Autowired
    private FPOShipmentRepo shipmentRepo;

    @Autowired
    private FormersRepo formersRepo;

    @Autowired
    private OrderRepo orderRepo;

    @Autowired
    private ShipmentNotificationService notificationService;

    @Autowired
    private GeocodingService geocodingService;

    @Autowired
    private RouteOptimizationService routeOptimizationService;

    @Autowired
    private DemoAccessService demoAccessService;


    // =========================================================
    // LOGGED-IN FARMER
    // =========================================================

    private Formers farmer(HttpSession session) {

        Object loggedInFormer =
                session.getAttribute("loggedInFormer");

        if (loggedInFormer instanceof Formers) {
            return (Formers) loggedInFormer;
        }

        Object former =
                session.getAttribute("former");

        if (former instanceof Formers) {
            return (Formers) former;
        }

        return null;
    }


    // =========================================================
    // ALL SHIPMENTS
    // =========================================================

    @GetMapping
    @Transactional(readOnly = true)
    public String list(
            @RequestParam(name = "demo", defaultValue = "false") boolean demo,
            HttpSession session,
            Model model,
            RedirectAttributes attributes) {

        Formers farmer = farmer(session);

        if (farmer == null) {

            attributes.addFlashAttribute(
                    "error",
                    "Farmer session expired."
            );

            return "redirect:/Flogin";
        }

        if (demo) {
            demoAccessService.requireFarmer(farmer);
        }

        List<FPOShipment> shipments =
                shipmentRepo.findByFarmerOrderByCreatedAtDesc(
                        farmer
                );

        shipments = shipments.stream()
                .filter(s -> s != null
                        && s.getOrder() != null
                        && s.getOrder().isDemoOrder() == demo)
                .toList();

        model.addAttribute(
                "shipments",
                shipments
        );

        model.addAttribute("demoMode", demo);

        model.addAttribute(
                "former",
                farmer
        );

        return "Former/shipments";
    }


    // =========================================================
    // CREATE SHIPMENT PAGE
    //
    // Works for:
    // 1. Real independent farmer orders
    // 2. Demo orders
    //
    // Demo order never changes Product inventory.
    // =========================================================

    @GetMapping("/Create")
    @Transactional(readOnly = true)
    public String createPage(
            @RequestParam Long orderId,
            HttpSession session,
            Model model,
            RedirectAttributes attributes) {

        Formers farmer = farmer(session);

        if (farmer == null) {

            attributes.addFlashAttribute(
                    "error",
                    "Farmer session expired."
            );

            return "redirect:/Flogin";
        }

        Order order =
                orderRepo.findByOrderId(orderId);

        if (order == null
                || order.getFarmer() == null
                || order.getFarmer().getId()
                        != farmer.getId()) {

            attributes.addFlashAttribute(
                    "error",
                    "Order not found or unauthorized."
            );

            return "redirect:/Former/Orders";
        }

        if (!"Confirmed".equalsIgnoreCase(
                order.getOrderStatus())) {

            attributes.addFlashAttribute(
                    "error",
                    "Only confirmed orders can be shipped."
            );

            return "redirect:/Former/Orders";
        }

        if (shipmentRepo.findByOrder(order).isPresent()) {

            attributes.addFlashAttribute(
                    "error",
                    "Shipment already exists."
            );

            return "redirect:/Former/Shipments";
        }

        model.addAttribute(
                "order",
                order
        );

        model.addAttribute(
                "former",
                farmer
        );

        model.addAttribute(
                "merchantAddress",
                order.getMerchant() != null
                        ? order.getMerchant().getAddress()
                        : ""
        );

        model.addAttribute(
                "merchantName",
                order.getMerchant() != null
                        ? order.getMerchant().getName()
                        : "Merchant"
        );

        /*
         * Important:
         *
         * isDemoOrder() is read only.
         * It does NOT touch farmer inventory.
         */
        model.addAttribute(
                "demoOrder",
                order.isDemoOrder()
        );

        return "Former/create-shipment";
    }


    // =========================================================
    // CREATE SHIPMENT
    // =========================================================

    @PostMapping("/Create")
    @Transactional
    public String create(
            @RequestParam Long orderId,
            @RequestParam String pickupAddress,
            @RequestParam(required = false)
                    String destinationAddress,
            @RequestParam(required = false)
                    String transporterName,
            @RequestParam(required = false)
                    String vehicleNumber,
            @RequestParam(required = false)
                    String estimatedDeliveryDate,
            HttpSession session,
            RedirectAttributes attributes) {

        Formers farmer = farmer(session);

        if (farmer == null) {

            attributes.addFlashAttribute(
                    "error",
                    "Farmer session expired."
            );

            return "redirect:/Flogin";
        }

        try {

            Order order =
                    orderRepo.findByOrderId(orderId);

            if (order == null
                    || order.getFarmer() == null
                    || order.getFarmer().getId()
                            != farmer.getId()) {

                throw new IllegalArgumentException(
                        "Order not found or unauthorized."
                );
            }

            if (!"Confirmed".equalsIgnoreCase(
                    order.getOrderStatus())) {

                throw new IllegalArgumentException(
                        "Only confirmed orders can be shipped."
                );
            }

            if (shipmentRepo.findByOrder(order).isPresent()) {

                throw new IllegalArgumentException(
                        "Shipment already exists."
                );
            }

            if (pickupAddress == null
                    || pickupAddress.isBlank()) {

                throw new IllegalArgumentException(
                        "Pickup address is required."
                );
            }


            // =================================================
            // MERCHANT DESTINATION
            // =================================================

            String merchantAddress = null;

            if (order.getMerchant() != null
                    && order.getMerchant().getAddress() != null
                    && !order.getMerchant()
                            .getAddress()
                            .isBlank()) {

                merchantAddress =
                        order.getMerchant()
                                .getAddress()
                                .trim();
            }


            // =================================================
            // FINAL DESTINATION
            // =================================================

            String finalDestination;

            if (destinationAddress != null
                    && !destinationAddress.isBlank()) {

                finalDestination =
                        destinationAddress.trim();

            } else if (merchantAddress != null) {

                finalDestination =
                        merchantAddress;

            } else {

                throw new IllegalArgumentException(
                        "Merchant destination address is not available."
                );
            }


            String finalPickupAddress =
                    normalizeAddress(
                            pickupAddress
                    );

            String normalizedDestination =
                    normalizeAddress(
                            finalDestination
                    );


            if (finalPickupAddress == null) {

                throw new IllegalArgumentException(
                        "Pickup address is invalid."
                );
            }

            if (normalizedDestination == null) {

                throw new IllegalArgumentException(
                        "Destination address is invalid."
                );
            }


            // =================================================
            // CREATE SHIPMENT
            // =================================================

            FPOShipment shipment =
                    new FPOShipment();

            shipment.setOrder(order);
            shipment.setFarmer(farmer);

            /*
             * Independent farmer shipments do not belong to an FPO.
             */
            shipment.setFpo(null);

            shipment.setPickupAddress(
                    finalPickupAddress
            );

            shipment.setDestinationAddress(
                    normalizedDestination
            );


            // =================================================
            // DEMO FLAG
            // =================================================

            boolean demoOrder =
                    order.isDemoOrder();

            /*
             * VERY IMPORTANT:
             *
             * Demo orders are shipment/route demonstrations only.
             *
             * We DO NOT modify:
             *
             * Product.quantity
             * Product.availableQuantity
             * Product.status
             *
             * here.
             *
             * Real order inventory behaviour remains untouched.
             */


            System.out.println(
                    "================================================="
            );

            System.out.println(
                    "CREATING FARMER SHIPMENT"
            );

            System.out.println(
                    "Order ID: "
                            + order.getOrderId()
            );

            System.out.println(
                    "Demo Order: "
                            + demoOrder
            );

            System.out.println(
                    "Pickup: "
                            + finalPickupAddress
            );

            System.out.println(
                    "Destination: "
                            + normalizedDestination
            );

            System.out.println(
                    "================================================="
            );


            // =================================================
            // GEOCODE PICKUP
            // =================================================

            GeocodingService.Coordinates pickupCoordinates =
                    geocodingService.geocode(
                            finalPickupAddress
                    );

            if (pickupCoordinates != null) {

                shipment.setPickupLatitude(
                        pickupCoordinates.getLatitude()
                );

                shipment.setPickupLongitude(
                        pickupCoordinates.getLongitude()
                );

                shipment.setGeocodeConfidenceScore(
                        pickupCoordinates
                                .getConfidenceScore()
                );

                shipment.setGeocodeSource(
                        pickupCoordinates.getSource()
                );

                shipment.setGeocodedAt(
                        LocalDateTime.now()
                );
            }


            // =================================================
            // GEOCODE DESTINATION
            // =================================================

            GeocodingService.Coordinates destinationCoordinates =
                    geocodingService.geocode(
                            normalizedDestination
                    );

            if (destinationCoordinates != null) {

                shipment.setDestinationLatitude(
                        destinationCoordinates.getLatitude()
                );

                shipment.setDestinationLongitude(
                        destinationCoordinates.getLongitude()
                );

                shipment.setGeocodeConfidenceScore(
                        destinationCoordinates
                                .getConfidenceScore()
                );

                shipment.setGeocodeSource(
                        destinationCoordinates.getSource()
                );

                shipment.setGeocodedAt(
                        LocalDateTime.now()
                );

            } else {

                System.out.println(
                        "WARNING: Destination could not be geocoded: "
                                + normalizedDestination
                );
            }


            // =================================================
            // TRANSPORTER
            // =================================================

            shipment.setTransporterName(
                    transporterName == null
                            || transporterName.isBlank()
                            ? "Demo Transporter"
                            : transporterName.trim()
            );

            shipment.setVehicleNumber(
                    vehicleNumber == null
                            || vehicleNumber.isBlank()
                            ? "DEMO-VEHICLE"
                            : vehicleNumber.trim()
            );


            // =================================================
            // STATUS
            // =================================================

            shipment.setStatus(
                    "Created"
            );

            shipment.setRouteOptimized(
                    false
            );

            shipment.setCreatedAt(
                    LocalDateTime.now()
            );


            // =================================================
            // ESTIMATED DELIVERY
            // =================================================

            if (estimatedDeliveryDate != null
                    && !estimatedDeliveryDate.isBlank()) {

                try {

                    shipment.setEstimatedDeliveryDate(
                             java.time.LocalDate.parse(
                                      estimatedDeliveryDate
                            ).atStartOfDay()

                    );

                } catch (Exception ignored) {

                    System.out.println(
                            "Invalid estimated delivery date: "
                                    + estimatedDeliveryDate
                    );
                }
            }


            shipmentRepo.save(shipment);


            attributes.addFlashAttribute(
                    "msg",
                    demoOrder
                            ? "Demo shipment created successfully. Farmer inventory was not changed."
                            : "Shipment created successfully."
            );

            return "redirect:/Former/Shipments?demo=" + demoOrder;

        } catch (Exception e) {

            attributes.addFlashAttribute(
                    "error",
                    "Unable to create shipment: "
                            + e.getMessage()
            );

            return "redirect:/Former/Orders";
        }
    }


    // =========================================================
    // OPTIMIZE ROUTE
    //
    // Example:
    // /Former/Shipments/OptimizeRoute?demo=true
    //
    // OR
    //
    // /Former/Shipments/OptimizeRoute?demo=false
    //
    // =========================================================

    @GetMapping("/OptimizeRoute")
    @Transactional
    public String optimizeRoute(
            @RequestParam(
                    value = "demo",
                    defaultValue = "false")
                    boolean demo,
            HttpSession session,
            Model model,
            RedirectAttributes attributes) {

        Formers farmer = farmer(session);

        if (farmer == null) {

            attributes.addFlashAttribute(
                    "error",
                    "Farmer session expired."
            );

            return "redirect:/Flogin";
        }

        try {

            List<FPOShipment> shipments =
                    shipmentRepo
                            .findByFarmerOrderByCreatedAtDesc(
                                    farmer
                            );

            /*
             * Only route shipments matching the requested mode.
             */
            List<FPOShipment> routeShipments =
                    new java.util.ArrayList<>();

            for (FPOShipment shipment : shipments) {

                if (shipment == null
                        || shipment.getOrder() == null) {

                    continue;
                }

                boolean shipmentIsDemo =
                        shipment.getOrder()
                                .isDemoOrder();

                if (shipmentIsDemo == demo) {

                    /*
                     * Only active/uncompleted shipments should
                     * participate in route optimization.
                     */
                    String status =
                            shipment.getStatus();

                    if (status == null
                            || !status.equalsIgnoreCase(
                                    "Delivered")) {

                        routeShipments.add(
                                shipment
                        );
                    }
                }
            }


            if (routeShipments.isEmpty()) {

                attributes.addFlashAttribute(
                        "error",
                        demo
                                ? "No demo shipments available for route optimization."
                                : "No real shipments available for route optimization."
                );

                return "redirect:/Former/Shipments";
            }


            // =================================================
            // CHECK COORDINATES
            // =================================================

            for (FPOShipment shipment :
                    routeShipments) {

                if (shipment.getPickupLatitude() == null
                        || shipment.getPickupLongitude() == null
                        || shipment.getDestinationLatitude() == null
                        || shipment.getDestinationLongitude() == null) {

                    /*
                     * Try to geocode again before failing.
                     */
                    if (shipment.getPickupAddress() != null) {

                        GeocodingService.Coordinates pickup =
                                geocodingService.geocode(
                                        shipment.getPickupAddress()
                                );

                        if (pickup != null) {

                            shipment.setPickupLatitude(
                                    pickup.getLatitude()
                            );

                            shipment.setPickupLongitude(
                                    pickup.getLongitude()
                            );
                        }
                    }


                    if (shipment.getDestinationAddress() != null) {

                        GeocodingService.Coordinates destination =
                                geocodingService.geocode(
                                        shipment.getDestinationAddress()
                                );

                        if (destination != null) {

                            shipment.setDestinationLatitude(
                                    destination.getLatitude()
                            );

                            shipment.setDestinationLongitude(
                                    destination.getLongitude()
                            );
                        }
                    }

                    shipmentRepo.save(
                            shipment
                    );
                }
            }


            // =================================================
            // PICKUP
            //
            // All shipments are expected to use the farmer's
            // pickup location.
            // =================================================

            FPOShipment first =
                    routeShipments.get(0);

            Double pickupLatitude =
                    first.getPickupLatitude();

            Double pickupLongitude =
                    first.getPickupLongitude();


            if (pickupLatitude == null
                    || pickupLongitude == null) {

                throw new IllegalArgumentException(
                        "Pickup coordinates are unavailable."
                );
            }


            // =================================================
            // ORS ROUTE OPTIMIZATION
            // =================================================

            System.out.println(
                    "================================================="
            );

            System.out.println(
                    "INDEPENDENT FARMER "
                            + (demo
                                    ? "DEMO "
                                    : "REAL ")
                            + "ROUTE OPTIMIZATION"
            );

            System.out.println(
                    "Pickup coordinates: "
                            + pickupLatitude
                            + ", "
                            + pickupLongitude
            );

            System.out.println(
                    "Destinations: "
                            + routeShipments.size()
            );

            System.out.println(
                    "================================================="
            );


            /*
             * IMPORTANT:
             *
             * RouteOptimizationService is reused.
             *
             * It calculates ROAD distance/time through ORS.
             *
             * It does NOT use straight-line distance.
             */
            RouteOptimizationResponse route =
                    routeOptimizationService.optimizeRoute(
                            routeShipments
                    );

            if (route == null
                    || route.getStops() == null
                    || route.getStops().isEmpty()) {

                attributes.addFlashAttribute(
                        "error",
                        route != null && route.getMessage() != null
                                ? route.getMessage()
                                : "Unable to optimize route."
                );

                return "redirect:/Former/Shipments?demo=" + demo;
            }

            model.addAttribute("route", route);
            model.addAttribute("former", farmer);
            model.addAttribute("demoMode", demo);
            model.addAttribute("active4", "active");

            return "Former/optimized-route";

        } catch (Exception e) {

            e.printStackTrace();

            attributes.addFlashAttribute(
                    "error",
                    "Route optimization failed: "
                            + e.getMessage()
            );

            return "redirect:/Former/Shipments?demo=" + demo;
        }
    }


    // =========================================================
    // DELIVERY
    // =========================================================

    @PostMapping("/Deliver")
    @Transactional
    public String deliver(
            @RequestParam Long shipmentId,
            HttpSession session,
            RedirectAttributes attributes) {

        Formers farmer = farmer(session);

        if (farmer == null) {

            attributes.addFlashAttribute(
                    "error",
                    "Farmer session expired."
            );

            return "redirect:/Flogin";
        }

        try {

            Optional<FPOShipment> optional =
                    shipmentRepo.findById(
                            shipmentId
                    );

            if (optional.isEmpty()) {

                throw new IllegalArgumentException(
                        "Shipment not found."
                );
            }

            FPOShipment shipment =
                    optional.get();

            if (shipment.getFarmer() != null
                    && shipment.getFarmer().getId()
                            != farmer.getId()) {

                throw new IllegalArgumentException(
                        "You are not authorized to update this shipment."
                );
            }

            /*
             * DEMO ORDER:
             *
             * Delivery changes shipment/order state only.
             *
             * NO farmer product inventory is touched.
             */
            boolean demoOrder =
                    shipment.getOrder() != null
                            && shipment.getOrder()
                                    .isDemoOrder();


            shipment.setStatus(
                    "Delivered"
            );

            shipment.setDeliveredAt(
                    LocalDateTime.now()
            );

            shipmentRepo.save(
                    shipment
            );


            if (shipment.getOrder() != null) {

                shipment.getOrder()
                        .setOrderStatus(
                                "Delivered"
                        );

                orderRepo.save(
                        shipment.getOrder()
                );
            }


            attributes.addFlashAttribute(
                    "msg",
                    demoOrder
                            ? "Demo order delivered successfully. Real farmer inventory was not changed."
                            : "Order delivered successfully."
            );

            return "redirect:/Former/Shipments?demo=" + demoOrder;

        } catch (Exception e) {

            attributes.addFlashAttribute(
                    "error",
                    "Unable to mark shipment delivered: "
                            + e.getMessage()
            );

            return "redirect:/Former/Shipments";
        }
    }


    // =========================================================
    // ADDRESS NORMALIZATION
    // =========================================================

    private String normalizeAddress(
            String address) {

        if (address == null) {
            return null;
        }

        String normalized =
                address
                        .replace('\n', ' ')
                        .replace('\r', ' ')
                        .replace('\t', ' ')
                        .replaceAll(
                                "\\s+",
                                " "
                        )
                        .trim();

        if (normalized.isBlank()) {
            return null;
        }

        /*
         * Always give geocoders Indian context where the user
         * has entered a short Lucknow address.
         */
        String lower =
                normalized.toLowerCase();

        if (lower.contains("lucknow")
                && !lower.contains(
                        "uttar pradesh")) {

            normalized +=
                    ", Uttar Pradesh";
        }

        if (lower.contains("lucknow")
                && !lower.contains(
                        "india")) {

            normalized +=
                    ", India";
        }

        return normalized;
    }
}

